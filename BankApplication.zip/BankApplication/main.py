from account import Account


def get_credentials():
    credentials_file = "credentials.csv"

    credentials = []
    with open(credentials_file) as f:
        lines = f.readlines()
        for line in lines[1:]:
            line_replaced = line.replace('\n', '')
            line_split = line_replaced.split(',')
            credentials.append(line_split)

    return credentials


def authenticate_user():
    credentials = get_credentials()
    while True:
        username = input("Please enter your username : ")
        password = input("Please enter your password : ")
        for user in credentials:
            if username == user[2] and password == user[3]:
                return user  # break out for loop
        else:
            print("Unregistered username")
            username = input("Please try another username : ")
            password = input("Please try another password : ")
            continue
        break

    print("Logged in as", username)


def get_roles_and_privileges():
    roles_and_privileges = {
        "admin": ["create client", "deposit", "logout"],
        "teller": ["issue loan", "see account", "logout"],
        "client": ["withdraw", "see balance", "transfer", "logout"]
    }

    return roles_and_privileges


def has_privileges(role, action):
    roles_and_privileges = get_roles_and_privileges()
    privileges = roles_and_privileges[role]
    has_privilege = action in privileges
    return has_privilege


def withdraw():
    amount = int(input('Enter the amount to withdraw: '))
    li = [authenticated_user[4]]
    balance = int(li[0])
    if amount > balance:
        print('Insufficient Balance!')
    else:
        balance -= amount
    print('Your Remaining Balance is: ' + str(balance))

    text = open("credentials.csv", "r")
    text = ''.join([i for i in text])
    text = text.replace(authenticated_user[4], str(balance))
    x = open("credentials.csv", "w")

    x.writelines(text)
    x.close()


def see_account():
    import csv
    with open('credentials.csv', 'rt') as f:
        reader = csv.reader(f)
        selected_details = input("Enter student ID for details: ")
        results = filter(lambda x: selected_details in x, reader)
        for line in results:
            print(line)


def issue_loan():
    import csv

    target_id = input("Enter target client id: ")

    with open('credentials.csv', 'r', newline='') as csvFile:
        for row in csv.reader(csvFile):
            if row[0] == target_id:
                amount = int(input('Enter the amount to deposit: '))
                o = [row[4]]
                i = [row[5]]
                loan_limit = int(i[0])
                balance = int(o[0])

                if loan_limit < 0:
                    print("Loan limit smaller than 0")
                else:
                    balance += amount
                    loan_limit -= amount

                    print(row[2] + ' Balance is: ' + str(balance))
                    print(row[2] + ' Loan Limit is: ' + str(loan_limit))

                    text = open("credentials.csv", "r")
                    text = ''.join([i for i in text])
                    text = text.replace(row[4], str(balance))
                    x = open("credentials.csv", "w")

                    x.writelines(text)
                    x.close()

                text2 = open("credentials.csv", "r")
                text2 = ''.join([i for i in text2])
                text2 = text2.replace(row[5], str(loan_limit))
                x2 = open("credentials.csv", "w")

                x2.writelines(text2)
                x2.close()
        else:
            pass


def transfer():
    import csv
    target_id = input("Write the id tha you want to transfer money: ")
    with open('credentials.csv', 'r', newline='') as csvFile:
        for row in csv.reader(csvFile):
            if row[0] == target_id:

                amount = int(input('Enter the amount to deposit: '))
                o = [row[4]]
                balance = int(o[0])
                if amount > balance:
                    print('Insufficient Balance!')
                else:
                    balance += amount

                    li = [authenticated_user[4]]
                    my_balance = int(li[0])
                    my_balance -= amount
                    print('Your Remaining Balance is: ' + str(my_balance))

                    text = open("credentials.csv", "r")
                    text = ''.join([i for i in text])
                    text = text.replace(authenticated_user[4], str(my_balance))
                    x = open("credentials.csv", "w")

                    x.writelines(text)
                    x.close()

                    print("Transferred successfully")

                text2 = open("credentials.csv", "r")
                text2 = ''.join([i for i in text2])
                text2 = text2.replace(row[4], str(balance))
                x2 = open("credentials.csv", "w")

                x2.writelines(text2)
                x2.close()


authenticated_user = None
while True:
    if not authenticated_user:
        authenticated_user = authenticate_user()
    command = input("What's the next command: ")
    if not has_privileges(authenticated_user[1], command):
        print("No privileges. Please try again!")
        continue
    if command == 'create client':
        Account().add_client()
    elif command == 'withdraw':
        withdraw()
    elif command == 'issue loan':
        issue_loan()
    elif command == 'see account':
        see_account()
    elif command == 'transfer':
        transfer()
    elif command == 'see balance':
        print("Your balance is: " + authenticated_user[4])
    elif command == 'logout':
        break
