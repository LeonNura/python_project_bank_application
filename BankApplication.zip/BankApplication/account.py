import csv
import os


class Account:
    def __init__(self):
        path = "Clients/"
        self.balance = 0
        self.role = input("Role: ")
        self.username = input("Username: ")
        self.password = input("Password: ")
        self.loan_limit = 10000



        print('Account Created.')

    def add_client(self):
        with open('credentials.csv', 'r') as f:
            opened_file = f.readlines()
            var = opened_file[-1].split(',')[0]
            var1 = int(var) + 1
            directory = self.username
            parent_dir = "Clients/"
            path = os.path.join(parent_dir, directory)
            os.mkdir(path)
        details = [var1, self.role, self.username, self.password, self.balance, self.loan_limit]

        file = open('credentials.csv', 'a', newline='')
        with file:
            write = csv.writer(file)
            write.writerow(details)